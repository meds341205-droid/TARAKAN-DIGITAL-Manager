# TARAKAN DIGITAL Manager
Business Cash & Transaction Tracker

Offline-first Philippine Peso bookkeeping and transaction manager for TARAKAN DIGITAL.

## Stack
- Kotlin
- Jetpack Compose + Material 3
- Room / SQLite
- KSP
- Android API 29+ (Android 10+)
- No login, PIN, password, biometric, or cloud requirement

## Build in AndroidIDE
1. Extract the ZIP.
2. Open the `TARAKAN-DIGITAL-Manager` folder as a Gradle project.
3. Let Gradle sync/download dependencies.
4. Build > Assemble Debug (or Run).
5. APK: `app/build/outputs/apk/debug/app-debug.apk`

## Release APK
Use AndroidIDE/Android Studio > Build > Generate Signed Bundle / APK > APK.

## Accounting rules implemented
- Cash In: cash + customer total; wallet - principal; income + fee.
- Cash Out: cash - principal; wallet + customer total; income + fee.
- Transfers: one account down, one account up; zero income.
- Utang borrow: funding account down; customer debt up; zero income.
- Utang payment: payment account up; customer debt down; zero income.
- Load: payment account up by selling price; cost account down by cost; income = selling price - cost.
- Starting balances are opening balances only, not income.
- Account balances are derived from opening balances + recorded transactions, so edits/deletes recalculate automatically.
