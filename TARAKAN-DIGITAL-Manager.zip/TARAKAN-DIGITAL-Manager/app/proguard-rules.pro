# TARAKAN DIGITAL Manager intentionally keeps release minification off in v1.
