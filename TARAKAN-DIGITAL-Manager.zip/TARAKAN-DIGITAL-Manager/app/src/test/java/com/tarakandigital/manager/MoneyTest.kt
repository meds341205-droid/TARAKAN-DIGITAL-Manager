package com.tarakandigital.manager

import com.tarakandigital.manager.repository.Money
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoneyTest {
    @Test fun parsesPesosExactly() {
        assertEquals(50000L, Money.parse("500"))
        assertEquals(51000L, Money.parse("₱510.00"))
        assertEquals(12345L, Money.parse("123.45"))
        assertNull(Money.parse("abc"))
    }

    @Test fun percentageFeeRoundsToCent() {
        assertEquals(1000L, Money.percentageFee(100000L, 1.0))
        assertEquals(125L, Money.percentageFee(10000L, 1.25))
    }
}
