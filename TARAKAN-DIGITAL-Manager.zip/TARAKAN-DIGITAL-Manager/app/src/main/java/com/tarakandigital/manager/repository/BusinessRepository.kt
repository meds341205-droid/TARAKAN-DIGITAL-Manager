package com.tarakandigital.manager.repository

import android.content.Context
import androidx.room.withTransaction
import com.tarakandigital.manager.data.BusinessDatabase
import com.tarakandigital.manager.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class BusinessRepository(private val db: BusinessDatabase) {
    private val accounts = db.accountDao()
    private val customers = db.customerDao()
    private val services = db.serviceDao()
    private val transactions = db.transactionDao()
    private val debts = db.debtDao()
    private val audits = db.auditDao()
    private val settings = db.settingsDao()

    suspend fun initialize() = withContext(Dispatchers.IO) {
        db.withTransaction {
            if (accounts.getAll().isEmpty()) {
                accounts.insertAll(
                    listOf(
                        AccountEntity(AccountIds.CASH, "Physical Cash", "💵"),
                        AccountEntity(AccountIds.GCASH, "GCash", "📱"),
                        AccountEntity(AccountIds.PALAWANPAY, "PalawanPay", "💳")
                    )
                )
            }
            if (services.getAllServices().isEmpty()) {
                val serviceRows = listOf(
                    ServiceTypeEntity(ServiceType.CASH_IN.name, ServiceType.CASH_IN.label),
                    ServiceTypeEntity(ServiceType.CASH_OUT.name, ServiceType.CASH_OUT.label),
                    ServiceTypeEntity(ServiceType.GCASH.name, ServiceType.GCASH.label),
                    ServiceTypeEntity(ServiceType.PALAWANPAY.name, ServiceType.PALAWANPAY.label),
                    ServiceTypeEntity(ServiceType.QR_CASH_IN.name, ServiceType.QR_CASH_IN.label),
                    ServiceTypeEntity(ServiceType.LOAD.name, ServiceType.LOAD.label),
                    ServiceTypeEntity(ServiceType.OTHER.name, ServiceType.OTHER.label)
                )
                services.insertServices(serviceRows)
                services.insertFees(
                    serviceRows.map {
                        ServiceFeeSettingEntity(
                            serviceCode = it.code,
                            feeMode = when (it.code) {
                                ServiceType.LOAD.name -> FeeMode.FIXED.name
                                else -> FeeMode.MANUAL.name
                            },
                            feeValue = 0.0,
                            defaultMarkupCents = 0L
                        )
                    }
                )
            }
            if (settings.get() == null) settings.save(AppSettingsEntity())
        }
    }

    suspend fun getSettings(): AppSettingsEntity = settings.get() ?: AppSettingsEntity()

    suspend fun completeSetup(cash: Long, gcash: Long, palawan: Long) = withContext(Dispatchers.IO) {
        db.withTransaction {
            val old = accounts.getAll().associateBy { it.id }
            accounts.insertAll(
                listOf(
                    AccountEntity(AccountIds.CASH, "Physical Cash", "💵", cash),
                    AccountEntity(AccountIds.GCASH, "GCash", "📱", gcash),
                    AccountEntity(AccountIds.PALAWANPAY, "PalawanPay", "💳", palawan)
                ).map { desired -> desired.copy(name = old[desired.id]?.name ?: desired.name) }
            )
            settings.save(AppSettingsEntity(setupComplete = true))
        }
    }

    suspend fun accountsSnapshot(): List<AccountEntity> = accounts.getAll()
    suspend fun customersSnapshot(): List<CustomerEntity> = customers.getAll()
    suspend fun servicesSnapshot(): List<ServiceTypeEntity> = services.getAllServices()
    suspend fun feeSettingsSnapshot(): List<ServiceFeeSettingEntity> = services.getFeeSettings()
    suspend fun transactionsSnapshot(): List<TransactionEntity> = transactions.getAll()
    suspend fun debtsSnapshot(): List<CustomerDebtTransactionEntity> = debts.getAll()
    suspend fun auditsSnapshot(): List<AuditEntity> = audits.getAll()

    suspend fun balances(): Map<String, Long> {
        val tx = transactions.getAll()
        val acc = accounts.getAll()
        return acc.associate { a -> a.id to AccountingCalculator.accountBalance(a.id, a.openingBalanceCents, tx) }
    }

    suspend fun totalServiceIncome(start: Long, end: Long): Long =
        transactions.getAll().filter { it.timestamp in start..end }.sumOf { it.incomeDeltaCents }

    suspend fun customerBalance(customerId: Long): Long = debts.getAll()
        .filter { it.customerId == customerId }
        .sumOf { if (it.debtType == DebtType.BORROW.name) it.amountCents else -it.amountCents }

    suspend fun totalUtang(): Long = debts.getAll().sumOf {
        if (it.debtType == DebtType.BORROW.name) it.amountCents else -it.amountCents
    }.coerceAtLeast(0L)

    suspend fun addCustomer(name: String, phone: String, notes: String): Long = withContext(Dispatchers.IO) {
        customers.insert(CustomerEntity(name = name.trim(), phone = phone.trim(), notes = notes.trim()))
    }

    suspend fun updateCustomer(item: CustomerEntity) = withContext(Dispatchers.IO) { customers.update(item) }

    suspend fun addServiceTransaction(
        serviceCode: String,
        amountCents: Long,
        feeCents: Long,
        source: String?,
        destination: String?,
        customerId: Long?,
        notes: String
    ): Long = withContext(Dispatchers.IO) {
        require(amountCents > 0L) { "Amount must be greater than zero." }
        val movement = when (serviceCode) {
            ServiceType.CASH_IN.name -> AccountingCalculator.movementForAccounts(
                source = AccountIds.CASH,
                destination = destination ?: AccountIds.GCASH,
                sourceAmount = amountCents + feeCents,
                destinationAmount = amountCents,
                income = feeCents
            )
            ServiceType.CASH_OUT.name -> AccountingCalculator.movementForAccounts(
                source = source ?: AccountIds.GCASH,
                destination = AccountIds.CASH,
                sourceAmount = amountCents + feeCents,
                destinationAmount = amountCents,
                income = feeCents
            )
            ServiceType.GCASH.name, ServiceType.PALAWANPAY.name, ServiceType.QR_CASH_IN.name ->
                AccountingCalculator.movementForAccounts(
                    source = source ?: AccountIds.CASH,
                    destination = destination ?: if (serviceCode == ServiceType.PALAWANPAY.name) AccountIds.PALAWANPAY else AccountIds.GCASH,
                    sourceAmount = amountCents + feeCents,
                    destinationAmount = amountCents,
                    income = feeCents
                )
            else -> {
                // Other services use a simple principal movement plus fee income.
                // The destination receives the customer's total payment so the fee remains part of business money.
                AccountingCalculator.movementForAccounts(
                    source = source,
                    destination = destination,
                    sourceAmount = amountCents,
                    destinationAmount = amountCents + feeCents,
                    income = feeCents
                )
            }
        }
        val tx = TransactionEntity(
            type = TxType.SERVICE.name,
            serviceCode = serviceCode,
            amountCents = amountCents,
            feeCents = feeCents,
            totalCustomerPaymentCents = amountCents + feeCents,
            sourceAccountId = source,
            destinationAccountId = destination,
            customerId = customerId,
            cashDeltaCents = movement.cash,
            gcashDeltaCents = movement.gcash,
            palawanPayDeltaCents = movement.palawan,
            incomeDeltaCents = movement.income,
            notes = notes.trim()
        )
        transactions.insert(tx)
    }

    suspend fun addLoadTransaction(
        costCents: Long,
        sellingPriceCents: Long,
        paymentAccountId: String,
        costAccountId: String,
        customerId: Long?,
        notes: String
    ): Long = withContext(Dispatchers.IO) {
        require(costCents > 0L && sellingPriceCents > 0L) { "Cost and selling price must be greater than zero." }
        val profit = sellingPriceCents - costCents
        val payment = AccountingCalculator.movementForAccounts(
            source = costAccountId,
            destination = paymentAccountId,
            sourceAmount = costCents,
            destinationAmount = sellingPriceCents,
            income = profit.coerceAtLeast(0L)
        )
        val tx = TransactionEntity(
            type = TxType.LOAD.name,
            serviceCode = ServiceType.LOAD.name,
            amountCents = sellingPriceCents,
            totalCustomerPaymentCents = sellingPriceCents,
            paymentAccountId = paymentAccountId,
            costAccountId = costAccountId,
            customerId = customerId,
            loadCostCents = costCents,
            sellingPriceCents = sellingPriceCents,
            cashDeltaCents = payment.cash,
            gcashDeltaCents = payment.gcash,
            palawanPayDeltaCents = payment.palawan,
            incomeDeltaCents = profit.coerceAtLeast(0L),
            notes = notes.trim()
        )
        transactions.insert(tx)
    }

    suspend fun addTransfer(source: String, destination: String, amountCents: Long, notes: String): Long = withContext(Dispatchers.IO) {
        require(source != destination) { "Choose different source and destination accounts." }
        require(amountCents > 0L) { "Transfer amount must be greater than zero." }
        val movement = AccountingCalculator.movementForAccounts(source, destination, amountCents, amountCents)
        transactions.insert(
            TransactionEntity(
                type = TxType.TRANSFER.name,
                amountCents = amountCents,
                sourceAccountId = source,
                destinationAccountId = destination,
                cashDeltaCents = movement.cash,
                gcashDeltaCents = movement.gcash,
                palawanPayDeltaCents = movement.palawan,
                incomeDeltaCents = 0L,
                notes = notes.trim()
            )
        )
    }

    suspend fun addDebtBorrow(customerId: Long, fundingAccount: String, amountCents: Long, notes: String): Long = withContext(Dispatchers.IO) {
        require(amountCents > 0L) { "Amount must be greater than zero." }
        db.withTransaction {
            val movement = AccountingCalculator.movementForAccounts(fundingAccount, null, amountCents, 0L)
            val txId = transactions.insert(
                TransactionEntity(
                    type = TxType.UTANG_BORROW.name,
                    amountCents = amountCents,
                    sourceAccountId = fundingAccount,
                    customerId = customerId,
                    cashDeltaCents = movement.cash,
                    gcashDeltaCents = movement.gcash,
                    palawanPayDeltaCents = movement.palawan,
                    incomeDeltaCents = 0L,
                    notes = notes.trim()
                )
            )
            debts.insert(
                CustomerDebtTransactionEntity(
                    customerId = customerId,
                    transactionId = txId,
                    debtType = DebtType.BORROW.name,
                    amountCents = amountCents,
                    timestamp = System.currentTimeMillis(),
                    notes = notes.trim()
                )
            )
            txId
        }
    }

    suspend fun addDebtPayment(customerId: Long, paymentAccount: String, amountCents: Long, notes: String): Long = withContext(Dispatchers.IO) {
        require(amountCents > 0L) { "Amount must be greater than zero." }
        val outstanding = customerBalance(customerId)
        require(amountCents <= outstanding) { "Payment cannot be more than the customer's outstanding balance." }
        db.withTransaction {
            val movement = AccountingCalculator.movementForAccounts(null, paymentAccount, 0L, amountCents)
            val txId = transactions.insert(
                TransactionEntity(
                    type = TxType.UTANG_PAYMENT.name,
                    amountCents = amountCents,
                    destinationAccountId = paymentAccount,
                    paymentAccountId = paymentAccount,
                    customerId = customerId,
                    cashDeltaCents = movement.cash,
                    gcashDeltaCents = movement.gcash,
                    palawanPayDeltaCents = movement.palawan,
                    incomeDeltaCents = 0L,
                    notes = notes.trim()
                )
            )
            debts.insert(
                CustomerDebtTransactionEntity(
                    customerId = customerId,
                    transactionId = txId,
                    debtType = DebtType.PAYMENT.name,
                    amountCents = amountCents,
                    paymentAccountId = paymentAccount,
                    timestamp = System.currentTimeMillis(),
                    notes = notes.trim()
                )
            )
            txId
        }
    }

    suspend fun updateTransaction(updated: TransactionEntity) = withContext(Dispatchers.IO) {
        db.withTransaction {
            transactions.update(updated)
            val debtRow = debts.getByTransactionId(updated.id)
            if (updated.type == TxType.UTANG_BORROW.name || updated.type == TxType.UTANG_PAYMENT.name) {
                if (debtRow != null && updated.customerId != null) {
                    debts.update(
                        debtRow.copy(
                            customerId = updated.customerId,
                            amountCents = updated.amountCents,
                            paymentAccountId = updated.paymentAccountId,
                            debtType = if (updated.type == TxType.UTANG_BORROW.name) DebtType.BORROW.name else DebtType.PAYMENT.name,
                            notes = updated.notes,
                            timestamp = updated.timestamp
                        )
                    )
                }
            } else if (debtRow != null) {
                debts.deleteByTransactionId(updated.id)
            }
        }
    }


    suspend fun editTransaction(id: Long, newAmountCents: Long, newFeeCents: Long, newCostCents: Long, newSellingPriceCents: Long, notes: String) = withContext(Dispatchers.IO) {
        require(newAmountCents > 0L) { "Amount must be greater than zero." }
        require(newFeeCents >= 0L) { "Fee cannot be negative." }
        val old = transactions.getById(id) ?: error("Transaction not found.")
        db.withTransaction {
            val updated = when (old.type) {
                TxType.SERVICE.name -> {
                    val movement = when (old.serviceCode) {
                        ServiceType.CASH_IN.name -> AccountingCalculator.movementForAccounts(
                            AccountIds.CASH, old.destinationAccountId ?: AccountIds.GCASH, newAmountCents + newFeeCents, newAmountCents, newFeeCents
                        )
                        ServiceType.CASH_OUT.name -> AccountingCalculator.movementForAccounts(
                            old.sourceAccountId ?: AccountIds.GCASH, AccountIds.CASH, newAmountCents + newFeeCents, newAmountCents, newFeeCents
                        )
                        ServiceType.GCASH.name, ServiceType.PALAWANPAY.name, ServiceType.QR_CASH_IN.name ->
                            AccountingCalculator.movementForAccounts(
                                old.sourceAccountId ?: AccountIds.CASH,
                                old.destinationAccountId ?: if (old.serviceCode == ServiceType.PALAWANPAY.name) AccountIds.PALAWANPAY else AccountIds.GCASH,
                                newAmountCents + newFeeCents, newAmountCents, newFeeCents
                            )
                        else -> AccountingCalculator.movementForAccounts(
                            old.sourceAccountId, old.destinationAccountId, newAmountCents, newAmountCents + newFeeCents, newFeeCents
                        )
                    }
                    old.copy(
                        amountCents = newAmountCents,
                        feeCents = newFeeCents,
                        totalCustomerPaymentCents = newAmountCents + newFeeCents,
                        cashDeltaCents = movement.cash,
                        gcashDeltaCents = movement.gcash,
                        palawanPayDeltaCents = movement.palawan,
                        incomeDeltaCents = newFeeCents,
                        notes = notes.trim()
                    )
                }
                TxType.LOAD.name -> {
                    require(newCostCents > 0L && newSellingPriceCents > 0L) { "Cost and selling price must be greater than zero." }
                    val profit = newSellingPriceCents - newCostCents
                    val movement = AccountingCalculator.movementForAccounts(
                        old.costAccountId, old.paymentAccountId, newCostCents, newSellingPriceCents, profit.coerceAtLeast(0L)
                    )
                    old.copy(
                        amountCents = newSellingPriceCents,
                        totalCustomerPaymentCents = newSellingPriceCents,
                        loadCostCents = newCostCents,
                        sellingPriceCents = newSellingPriceCents,
                        cashDeltaCents = movement.cash,
                        gcashDeltaCents = movement.gcash,
                        palawanPayDeltaCents = movement.palawan,
                        incomeDeltaCents = profit.coerceAtLeast(0L),
                        notes = notes.trim()
                    )
                }
                TxType.TRANSFER.name -> {
                    val movement = AccountingCalculator.movementForAccounts(old.sourceAccountId, old.destinationAccountId, newAmountCents, newAmountCents)
                    old.copy(
                        amountCents = newAmountCents,
                        cashDeltaCents = movement.cash,
                        gcashDeltaCents = movement.gcash,
                        palawanPayDeltaCents = movement.palawan,
                        incomeDeltaCents = 0L,
                        notes = notes.trim()
                    )
                }
                TxType.UTANG_BORROW.name -> {
                    val movement = AccountingCalculator.movementForAccounts(old.sourceAccountId, null, newAmountCents, 0L)
                    old.copy(
                        amountCents = newAmountCents,
                        cashDeltaCents = movement.cash,
                        gcashDeltaCents = movement.gcash,
                        palawanPayDeltaCents = movement.palawan,
                        notes = notes.trim()
                    )
                }
                TxType.UTANG_PAYMENT.name -> {
                    val outstandingWithOld = customerBalance(old.customerId ?: 0L)
                    val maxAllowed = outstandingWithOld + old.amountCents
                    require(newAmountCents <= maxAllowed) { "Payment cannot exceed the customer's outstanding balance." }
                    val movement = AccountingCalculator.movementForAccounts(null, old.paymentAccountId, 0L, newAmountCents)
                    old.copy(
                        amountCents = newAmountCents,
                        cashDeltaCents = movement.cash,
                        gcashDeltaCents = movement.gcash,
                        palawanPayDeltaCents = movement.palawan,
                        notes = notes.trim()
                    )
                }
                else -> old.copy(amountCents = newAmountCents, notes = notes.trim())
            }
            transactions.update(updated)
            val debtRow = debts.getByTransactionId(id)
            if (debtRow != null) {
                debts.update(debtRow.copy(amountCents = updated.amountCents, notes = updated.notes, timestamp = updated.timestamp))
            }
        }
    }

    suspend fun deleteTransaction(id: Long) = withContext(Dispatchers.IO) {
        db.withTransaction {
            debts.deleteByTransactionId(id)
            transactions.deleteById(id)
        }
    }

    suspend fun addAudit(actualCashCents: Long, notes: String): AuditEntity = withContext(Dispatchers.IO) {
        val expected = balances()[AccountIds.CASH] ?: 0L
        val difference = actualCashCents - expected
        val audit = AuditEntity(expected, actualCashCents, difference, notes = notes.trim())
        val id = audits.insert(audit)
        audit.copy(id = id)
    }

    suspend fun saveFeeSetting(setting: ServiceFeeSettingEntity) = withContext(Dispatchers.IO) {
        services.insertFees(listOf(setting))
    }

    suspend fun exportJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("settings", (settings.get() ?: AppSettingsEntity()).toJson())
        root.put("accounts", JSONArray(accounts.getAll().map { it.toJson() }))
        root.put("customers", JSONArray(customers.getAll().map { it.toJson() }))
        root.put("services", JSONArray(services.getAllServices().map { it.toJson() }))
        root.put("fees", JSONArray(services.getFeeSettings().map { it.toJson() }))
        root.put("transactions", JSONArray(transactions.getAll().map { it.toJson() }))
        root.put("debts", JSONArray(debts.getAll().map { it.toJson() }))
        root.put("audits", JSONArray(audits.getAll().map { it.toJson() }))
        root.toString(2)
    }

    suspend fun importJson(json: String) = withContext(Dispatchers.IO) {
        val root = JSONObject(json)
        require(root.optInt("version", 1) == 1) { "Unsupported backup version." }
        db.withTransaction {
            debts.deleteAll()
            transactions.deleteAll()
            audits.deleteAll()
            // Keep foreign-key order safe: children first, then parent tables.
            customers.getAll().forEach { customers.delete(it) }
            val accountsJson = root.optJSONArray("accounts") ?: JSONArray()
            val customersJson = root.optJSONArray("customers") ?: JSONArray()
            val servicesJson = root.optJSONArray("services") ?: JSONArray()
            val feesJson = root.optJSONArray("fees") ?: JSONArray()
            val txJson = root.optJSONArray("transactions") ?: JSONArray()
            val debtJson = root.optJSONArray("debts") ?: JSONArray()
            val auditJson = root.optJSONArray("audits") ?: JSONArray()

            accounts.insertAll((0 until accountsJson.length()).map { accountFromJson(accountsJson.getJSONObject(it)) })
            customersJson.forEachObject { customers.insert(it.toCustomer()) }
            services.insertServices((0 until servicesJson.length()).map { serviceFromJson(servicesJson.getJSONObject(it)) })
            services.insertFees((0 until feesJson.length()).map { feeFromJson(feesJson.getJSONObject(it)) })
            txJson.forEachObject { transactions.insert(it.toTransaction()) }
            debtJson.forEachObject { debts.insert(it.toDebt()) }
            auditJson.forEachObject { audits.insert(it.toAudit()) }
            root.optJSONObject("settings")?.let { settings.save(it.toSettings()) }
        }
    }

    suspend fun reportTransactions(start: Long, end: Long): List<TransactionEntity> = transactions.getAll()
        .filter { it.timestamp in start..end }
        .sortedByDescending { it.timestamp }
}

private fun CustomerEntity.toJson() = JSONObject()
    .put("id", id).put("name", name).put("phone", phone).put("notes", notes).put("createdAt", createdAt)
private fun ServiceTypeEntity.toJson() = JSONObject().put("code", code).put("name", name).put("enabled", enabled)
private fun ServiceFeeSettingEntity.toJson() = JSONObject().put("serviceCode", serviceCode).put("feeMode", feeMode).put("feeValue", feeValue).put("defaultMarkupCents", defaultMarkupCents)
private fun AccountEntity.toJson() = JSONObject().put("id", id).put("name", name).put("icon", icon).put("openingBalanceCents", openingBalanceCents)
private fun TransactionEntity.toJson() = JSONObject()
    .put("id", id).put("type", type).putNullable("serviceCode", serviceCode).put("amountCents", amountCents)
    .put("feeCents", feeCents).put("totalCustomerPaymentCents", totalCustomerPaymentCents)
    .putNullable("sourceAccountId", sourceAccountId).putNullable("destinationAccountId", destinationAccountId)
    .putNullable("paymentAccountId", paymentAccountId).putNullable("costAccountId", costAccountId)
    .putNullable("customerId", customerId).put("loadCostCents", loadCostCents).put("sellingPriceCents", sellingPriceCents)
    .put("cashDeltaCents", cashDeltaCents).put("gcashDeltaCents", gcashDeltaCents).put("palawanPayDeltaCents", palawanPayDeltaCents)
    .put("incomeDeltaCents", incomeDeltaCents).put("timestamp", timestamp).put("notes", notes)
private fun CustomerDebtTransactionEntity.toJson() = JSONObject()
    .put("id", id).put("customerId", customerId).put("transactionId", transactionId).put("debtType", debtType)
    .put("amountCents", amountCents).putNullable("paymentAccountId", paymentAccountId).put("timestamp", timestamp).put("notes", notes)
private fun AuditEntity.toJson() = JSONObject().put("id", id).put("expectedCashCents", expectedCashCents)
    .put("actualCashCents", actualCashCents).put("differenceCents", differenceCents).put("timestamp", timestamp).put("notes", notes)
private fun AppSettingsEntity.toJson() = JSONObject().put("id", id).put("setupComplete", setupComplete).put("businessName", businessName).put("tagline", tagline)

private fun JSONObject.putNullable(key: String, value: Any?): JSONObject = if (value == null) put(key, JSONObject.NULL) else put(key, value)
private fun JSONObject.optNullableString(key: String): String? = if (isNull(key)) null else optString(key, null)
private fun JSONObject.optNullableLong(key: String): Long? = if (isNull(key)) null else optLong(key)

private fun JSONObject.toCustomer() = CustomerEntity(getLong("id"), getString("name"), optString("phone"), optString("notes"), getLong("createdAt"))
private fun JSONObject.toTransaction() = TransactionEntity(
    id = getLong("id"), type = getString("type"), serviceCode = optNullableString("serviceCode"), amountCents = getLong("amountCents"),
    feeCents = getLong("feeCents"), totalCustomerPaymentCents = getLong("totalCustomerPaymentCents"), sourceAccountId = optNullableString("sourceAccountId"),
    destinationAccountId = optNullableString("destinationAccountId"), paymentAccountId = optNullableString("paymentAccountId"), costAccountId = optNullableString("costAccountId"),
    customerId = optNullableLong("customerId"), loadCostCents = getLong("loadCostCents"), sellingPriceCents = getLong("sellingPriceCents"),
    cashDeltaCents = getLong("cashDeltaCents"), gcashDeltaCents = getLong("gcashDeltaCents"), palawanPayDeltaCents = getLong("palawanPayDeltaCents"),
    incomeDeltaCents = getLong("incomeDeltaCents"), timestamp = getLong("timestamp"), notes = optString("notes")
)
private fun JSONObject.toDebt() = CustomerDebtTransactionEntity(
    id = getLong("id"), customerId = getLong("customerId"), transactionId = getLong("transactionId"), debtType = getString("debtType"),
    amountCents = getLong("amountCents"), paymentAccountId = optNullableString("paymentAccountId"), timestamp = getLong("timestamp"), notes = optString("notes")
)
private fun JSONObject.toAudit() = AuditEntity(getLong("id"), getLong("expectedCashCents"), getLong("actualCashCents"), getLong("differenceCents"), getLong("timestamp"), optString("notes"))
private fun JSONObject.toSettings() = AppSettingsEntity(getInt("id"), getBoolean("setupComplete"), optString("businessName"), optString("tagline"))
private fun serviceFromJson(json: JSONObject): ServiceTypeEntity = ServiceTypeEntity(
    json.getString("code"), json.getString("name"), json.optBoolean("enabled", true)
)
private fun feeFromJson(json: JSONObject): ServiceFeeSettingEntity = ServiceFeeSettingEntity(
    json.getString("serviceCode"), json.optString("feeMode", FeeMode.MANUAL.name), json.optDouble("feeValue", 0.0), json.optLong("defaultMarkupCents", 0L)
)
private fun accountFromJson(json: JSONObject): AccountEntity = AccountEntity(
    json.getString("id"), json.getString("name"), json.getString("icon"), json.optLong("openingBalanceCents", 0L)
)

private fun JSONArray.forEachObject(block: (JSONObject) -> Unit) {
    for (i in 0 until length()) block(getJSONObject(i))
}

private object Companions {
    val unused = Unit
}
