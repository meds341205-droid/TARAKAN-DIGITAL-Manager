package com.tarakandigital.manager.repository

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId

object DateUtils {
    fun startOf(date: LocalDate): Long = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    fun endOf(date: LocalDate): Long = date.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() - 1L

    fun todayStart(): Long = startOf(LocalDate.now())
    fun todayEnd(): Long = endOf(LocalDate.now())

    fun thisWeekStart(): Long {
        val today = LocalDate.now()
        val monday = today.with(DayOfWeek.MONDAY)
        return startOf(monday)
    }

    fun thisMonthStart(): Long = startOf(LocalDate.now().withDayOfMonth(1))
}
