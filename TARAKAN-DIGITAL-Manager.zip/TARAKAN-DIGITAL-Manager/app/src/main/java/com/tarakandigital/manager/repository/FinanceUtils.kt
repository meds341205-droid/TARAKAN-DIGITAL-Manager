package com.tarakandigital.manager.repository

import com.tarakandigital.manager.model.AccountIds
import com.tarakandigital.manager.model.TransactionEntity

data class Movement(
    val cash: Long = 0L,
    val gcash: Long = 0L,
    val palawan: Long = 0L,
    val income: Long = 0L
)

object AccountingCalculator {
    fun accountBalance(account: String, openingCents: Long, transactions: List<TransactionEntity>): Long {
        return openingCents + transactions.sumOf { tx ->
            when (account) {
                AccountIds.CASH -> tx.cashDeltaCents
                AccountIds.GCASH -> tx.gcashDeltaCents
                AccountIds.PALAWANPAY -> tx.palawanPayDeltaCents
                else -> 0L
            }
        }
    }

    fun movementForAccounts(
        source: String?,
        destination: String?,
        sourceAmount: Long,
        destinationAmount: Long,
        income: Long = 0L
    ): Movement {
        val cash = when {
            source == AccountIds.CASH -> -sourceAmount
            destination == AccountIds.CASH -> destinationAmount
            else -> 0L
        }
        val gcash = when {
            source == AccountIds.GCASH -> -sourceAmount
            destination == AccountIds.GCASH -> destinationAmount
            else -> 0L
        }
        val palawan = when {
            source == AccountIds.PALAWANPAY -> -sourceAmount
            destination == AccountIds.PALAWANPAY -> destinationAmount
            else -> 0L
        }
        return Movement(cash, gcash, palawan, income)
    }
}
