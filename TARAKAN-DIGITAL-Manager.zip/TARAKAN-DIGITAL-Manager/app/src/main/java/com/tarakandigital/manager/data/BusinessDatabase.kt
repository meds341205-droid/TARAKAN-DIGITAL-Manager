package com.tarakandigital.manager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.tarakandigital.manager.model.*

@Database(
    entities = [
        AccountEntity::class,
        CustomerEntity::class,
        ServiceTypeEntity::class,
        ServiceFeeSettingEntity::class,
        TransactionEntity::class,
        CustomerDebtTransactionEntity::class,
        AuditEntity::class,
        AppSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BusinessDatabase : RoomDatabase() {
    abstract fun accountDao(): AccountDao
    abstract fun customerDao(): CustomerDao
    abstract fun serviceDao(): ServiceDao
    abstract fun transactionDao(): TransactionDao
    abstract fun debtDao(): DebtDao
    abstract fun auditDao(): AuditDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile private var INSTANCE: BusinessDatabase? = null

        fun get(context: Context): BusinessDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                BusinessDatabase::class.java,
                "tarakan_digital_manager.db"
            ).build().also { INSTANCE = it }
        }
    }
}
