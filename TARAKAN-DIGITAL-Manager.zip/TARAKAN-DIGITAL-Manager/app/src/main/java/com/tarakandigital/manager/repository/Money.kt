package com.tarakandigital.manager.repository

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale

object Money {
    private val pesoFormat = NumberFormat.getCurrencyInstance(Locale("en", "PH"))

    fun format(cents: Long): String = pesoFormat.format(cents / 100.0)
        .replace("PHP", "₱")
        .replace("PHP ", "₱")

    fun parse(text: String): Long? {
        val cleaned = text.trim().replace("₱", "").replace(",", "")
        if (cleaned.isBlank()) return null
        return try {
            BigDecimal(cleaned).setScale(2, RoundingMode.HALF_UP)
                .movePointRight(2).longValueExact()
        } catch (_: Exception) {
            null
        }
    }

    fun percentageFee(amountCents: Long, percent: Double): Long {
        if (amountCents <= 0L || percent <= 0.0) return 0L
        return BigDecimal.valueOf(amountCents)
            .multiply(BigDecimal.valueOf(percent))
            .divide(BigDecimal("100"), 0, RoundingMode.HALF_UP)
            .toLong()
    }
}
