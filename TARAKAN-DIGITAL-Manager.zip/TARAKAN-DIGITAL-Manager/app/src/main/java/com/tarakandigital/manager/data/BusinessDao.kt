package com.tarakandigital.manager.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.tarakandigital.manager.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY name")
    suspend fun getAll(): List<AccountEntity>

    @Query("SELECT * FROM accounts ORDER BY name")
    fun observeAll(): Flow<List<AccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<AccountEntity>)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<CustomerEntity>

    @Query("SELECT * FROM customers ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): CustomerEntity?

    @Insert
    suspend fun insert(item: CustomerEntity): Long

    @Update
    suspend fun update(item: CustomerEntity)

    @Delete
    suspend fun delete(item: CustomerEntity)
}

@Dao
interface ServiceDao {
    @Query("SELECT * FROM service_types WHERE enabled = 1 ORDER BY name")
    suspend fun getServices(): List<ServiceTypeEntity>

    @Query("SELECT * FROM service_types ORDER BY name")
    suspend fun getAllServices(): List<ServiceTypeEntity>

    @Query("SELECT * FROM service_fee_settings ORDER BY serviceCode")
    suspend fun getFeeSettings(): List<ServiceFeeSettingEntity>

    @Query("SELECT * FROM service_fee_settings WHERE serviceCode = :code LIMIT 1")
    suspend fun getFee(code: String): ServiceFeeSettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServices(items: List<ServiceTypeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFees(items: List<ServiceFeeSettingEntity>)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    suspend fun getAll(): List<TransactionEntity>

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): TransactionEntity?

    @Insert
    suspend fun insert(item: TransactionEntity): Long

    @Update
    suspend fun update(item: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM transactions")
    suspend fun deleteAll()
}

@Dao
interface DebtDao {
    @Query("SELECT * FROM customer_debt_transactions ORDER BY timestamp DESC")
    suspend fun getAll(): List<CustomerDebtTransactionEntity>

    @Query("SELECT * FROM customer_debt_transactions WHERE transactionId = :txId LIMIT 1")
    suspend fun getByTransactionId(txId: Long): CustomerDebtTransactionEntity?

    @Insert
    suspend fun insert(item: CustomerDebtTransactionEntity): Long

    @Update
    suspend fun update(item: CustomerDebtTransactionEntity)

    @Query("DELETE FROM customer_debt_transactions WHERE transactionId = :txId")
    suspend fun deleteByTransactionId(txId: Long)

    @Query("DELETE FROM customer_debt_transactions")
    suspend fun deleteAll()
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audits ORDER BY timestamp DESC")
    suspend fun getAll(): List<AuditEntity>

    @Insert
    suspend fun insert(item: AuditEntity): Long

    @Query("DELETE FROM audits")
    suspend fun deleteAll()
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    suspend fun get(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(item: AppSettingsEntity)
}
