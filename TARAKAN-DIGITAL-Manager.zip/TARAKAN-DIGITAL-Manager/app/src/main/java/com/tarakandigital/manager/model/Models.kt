package com.tarakandigital.manager.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

object AccountIds {
    const val CASH = "cash"
    const val GCASH = "gcash"
    const val PALAWANPAY = "palawanpay"
}

enum class TxType(val label: String) {
    SERVICE("Service"),
    LOAD("Load"),
    UTANG_BORROW("New Utang"),
    UTANG_PAYMENT("Utang Payment"),
    TRANSFER("Transfer"),
    ADJUSTMENT("Adjustment")
}

enum class ServiceType(val label: String) {
    CASH_IN("Cash In"),
    CASH_OUT("Cash Out"),
    GCASH("GCash"),
    PALAWANPAY("PalawanPay"),
    QR_CASH_IN("QR Cash-In"),
    LOAD("Load"),
    OTHER("Other")
}

enum class FeeMode(val label: String) {
    FIXED("Fixed Fee"),
    PERCENT("Percentage Fee"),
    MANUAL("Manual Fee")
}

enum class DebtType { BORROW, PAYMENT }

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val name: String,
    val icon: String,
    val openingBalanceCents: Long = 0L
)

@Entity(
    tableName = "customers",
    indices = [Index(value = ["name"])]
)
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val phone: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "service_types",
    indices = [Index(value = ["code"], unique = true)]
)
data class ServiceTypeEntity(
    @PrimaryKey val code: String,
    val name: String,
    val enabled: Boolean = true
)

@Entity(
    tableName = "service_fee_settings",
    primaryKeys = ["serviceCode"],
    foreignKeys = [
        ForeignKey(
            entity = ServiceTypeEntity::class,
            parentColumns = ["code"],
            childColumns = ["serviceCode"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ServiceFeeSettingEntity(
    val serviceCode: String,
    val feeMode: String = FeeMode.MANUAL.name,
    val feeValue: Double = 0.0,
    val defaultMarkupCents: Long = 0L
)

@Entity(
    tableName = "transactions",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["type"]),
        Index(value = ["serviceCode"]),
        Index(value = ["customerId"])
    ]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val type: String,
    val serviceCode: String? = null,
    val amountCents: Long = 0L,
    val feeCents: Long = 0L,
    val totalCustomerPaymentCents: Long = 0L,
    val sourceAccountId: String? = null,
    val destinationAccountId: String? = null,
    val paymentAccountId: String? = null,
    val costAccountId: String? = null,
    val customerId: Long? = null,
    val loadCostCents: Long = 0L,
    val sellingPriceCents: Long = 0L,
    val cashDeltaCents: Long = 0L,
    val gcashDeltaCents: Long = 0L,
    val palawanPayDeltaCents: Long = 0L,
    val incomeDeltaCents: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(
    tableName = "customer_debt_transactions",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = TransactionEntity::class,
            parentColumns = ["id"],
            childColumns = ["transactionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["customerId"]), Index(value = ["transactionId"], unique = true)]
)
data class CustomerDebtTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val customerId: Long,
    val transactionId: Long,
    val debtType: String,
    val amountCents: Long,
    val paymentAccountId: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "audits", indices = [Index(value = ["timestamp"])])
data class AuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val expectedCashCents: Long,
    val actualCashCents: Long,
    val differenceCents: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val setupComplete: Boolean = false,
    val businessName: String = "TARAKAN DIGITAL",
    val tagline: String = "Business Cash & Transaction Tracker"
)
