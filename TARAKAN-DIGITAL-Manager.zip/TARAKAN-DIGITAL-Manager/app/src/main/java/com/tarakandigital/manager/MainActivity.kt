package com.tarakandigital.manager

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tarakandigital.manager.data.BusinessDatabase
import com.tarakandigital.manager.model.*
import com.tarakandigital.manager.repository.BusinessRepository
import com.tarakandigital.manager.repository.DateUtils
import com.tarakandigital.manager.repository.Money
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF0F3D2E)
private val Green2 = Color(0xFF176A4B)
private val Mint = Color(0xFFE7F5EC)
private val Bg = Color(0xFFF5F7F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = BusinessDatabase.get(applicationContext)
        setContent {
            val vm: BusinessViewModel = viewModel(factory = BusinessViewModelFactory(db))
            TarakanTheme {
                TarakanApp(vm)
            }
        }
    }
}

class BusinessViewModelFactory(private val db: BusinessDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return BusinessViewModel(BusinessRepository(db)) as T
    }
}

data class UiState(
    val setupComplete: Boolean = false,
    val cash: Long = 0L,
    val gcash: Long = 0L,
    val palawan: Long = 0L,
    val utang: Long = 0L,
    val incomeToday: Long = 0L,
    val transactions: List<TransactionEntity> = emptyList(),
    val customers: List<CustomerEntity> = emptyList(),
    val customerBalances: Map<Long, Long> = emptyMap(),
    val services: List<ServiceTypeEntity> = emptyList(),
    val fees: Map<String, ServiceFeeSettingEntity> = emptyMap(),
    val audits: List<AuditEntity> = emptyList(),
    val loading: Boolean = true,
    val error: String? = null,
    val message: String? = null
) {
    val totalBusinessMoney: Long get() = cash + gcash + palawan
}

class BusinessViewModel(private val repo: BusinessRepository) : ViewModel() {
    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    init {
        refresh()
    }

    fun clearMessage() { _ui.value = _ui.value.copy(message = null, error = null) }

    fun refresh() {
        viewModelScope.launch {
            try {
                repo.initialize()
                val s = repo.getSettings()
                val balances = repo.balances()
                val tx = repo.transactionsSnapshot()
                val cust = repo.customersSnapshot()
                val balancesByCustomer = cust.associate { it.id to repo.customerBalance(it.id) }
                _ui.value = UiState(
                    setupComplete = s.setupComplete,
                    cash = balances[AccountIds.CASH] ?: 0L,
                    gcash = balances[AccountIds.GCASH] ?: 0L,
                    palawan = balances[AccountIds.PALAWANPAY] ?: 0L,
                    utang = repo.totalUtang(),
                    incomeToday = repo.totalServiceIncome(DateUtils.todayStart(), DateUtils.todayEnd()),
                    transactions = tx,
                    customers = cust,
                    customerBalances = balancesByCustomer,
                    services = repo.servicesSnapshot(),
                    fees = repo.feeSettingsSnapshot().associateBy { it.serviceCode },
                    audits = repo.auditsSnapshot(),
                    loading = false
                )
            } catch (e: Exception) {
                _ui.value = _ui.value.copy(loading = false, error = e.message ?: "Unable to load data.")
            }
        }
    }

    fun completeSetup(cash: Long, gcash: Long, palawan: Long) = action("Setup saved") {
        repo.completeSetup(cash, gcash, palawan)
        refresh()
    }

    fun addCustomer(name: String, phone: String, notes: String) = action("Customer added") {
        require(name.isNotBlank()) { "Customer name is required." }
        repo.addCustomer(name, phone, notes)
        refresh()
    }

    fun addService(service: String, amount: Long, fee: Long, source: String?, destination: String?, customerId: Long?, notes: String) = action("Transaction saved") {
        repo.addServiceTransaction(service, amount, fee, source, destination, customerId, notes)
        refresh()
    }

    fun addLoad(cost: Long, selling: Long, paymentAccount: String, costAccount: String, customerId: Long?, notes: String) = action("Load transaction saved") {
        repo.addLoadTransaction(cost, selling, paymentAccount, costAccount, customerId, notes)
        refresh()
    }

    fun addTransfer(source: String, destination: String, amount: Long, notes: String) = action("Transfer saved") {
        repo.addTransfer(source, destination, amount, notes)
        refresh()
    }

    fun addBorrow(customerId: Long, account: String, amount: Long, notes: String) = action("Utang recorded") {
        repo.addDebtBorrow(customerId, account, amount, notes)
        refresh()
    }

    fun addPayment(customerId: Long, account: String, amount: Long, notes: String) = action("Utang payment recorded") {
        repo.addDebtPayment(customerId, account, amount, notes)
        refresh()
    }

    fun addAudit(actual: Long, notes: String) = action("Audit saved") {
        repo.addAudit(actual, notes)
        refresh()
    }

    fun editTransaction(tx: TransactionEntity, amount: Long, fee: Long, cost: Long, selling: Long, notes: String) = action("Transaction updated") {
        repo.editTransaction(tx.id, amount, fee, cost, selling, notes)
        refresh()
    }

    fun deleteTransaction(id: Long) = action("Transaction deleted") {
        repo.deleteTransaction(id)
        refresh()
    }

    fun saveFeeSetting(setting: ServiceFeeSettingEntity) = action("Service setting saved") {
        repo.saveFeeSetting(setting)
        refresh()
    }

    fun exportBackup(write: suspend (String) -> Unit) = action("Backup created") {
        write(repo.exportJson())
    }

    fun importBackup(json: String) = action("Backup restored") {
        repo.importJson(json)
        refresh()
    }

    private fun action(message: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                _ui.value = _ui.value.copy(error = null, message = null)
                block()
                _ui.value = _ui.value.copy(message = message)
            } catch (e: Exception) {
                _ui.value = _ui.value.copy(error = e.message ?: "Operation failed.")
            }
        }
    }
}


@Composable
fun TarakanTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            secondary = Green2,
            background = Bg,
            surface = Color.White
        ),
        typography = Typography(
            headlineSmall = LocalTextStyle.current.copy(fontSize = 25.sp, fontWeight = FontWeight.Bold),
            titleLarge = LocalTextStyle.current.copy(fontSize = 21.sp, fontWeight = FontWeight.Bold)
        ),
        content = content
    )
}

private enum class Screen { DASHBOARD, HISTORY, UTANG, REPORTS, SETTINGS, FORM, LOAD, TRANSFER, AUDIT, DEBT, EDIT }

@Composable
fun TarakanApp(vm: BusinessViewModel) {
    val ui by vm.ui.collectAsState()
    var screen by remember { mutableStateOf(Screen.DASHBOARD) }
    var presetService by remember { mutableStateOf(ServiceType.CASH_IN.name) }
    var debtMode by remember { mutableStateOf(DebtType.BORROW.name) }
    var selectedCustomerId by remember { mutableStateOf<Long?>(null) }
    var selectedTransaction by remember { mutableStateOf<TransactionEntity?>(null) }
    val scope = rememberCoroutineScope()
    var showDelete by remember { mutableStateOf<TransactionEntity?>(null) }

    // SAF callbacks need the context from Compose, so a second launcher is declared below using LocalContext.
    val context = androidx.compose.ui.platform.LocalContext.current
    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportBackup { json -> context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) } ?: error("Cannot write backup file.") }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("Cannot read backup file.")
                vm.importBackup(json)
            } catch (e: Exception) {
                // The ViewModel exposes errors for database failures; file read errors are shown through a lightweight toast.
                android.widget.Toast.makeText(context, e.message ?: "Unable to restore backup.", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    if (ui.loading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    if (!ui.setupComplete) {
        FirstSetupScreen(onSave = vm::completeSetup)
        return
    }

    if (ui.error != null) {
        AlertDialog(onDismissRequest = vm::clearMessage, confirmButton = { TextButton(onClick = vm::clearMessage) { Text("OK") } }, title = { Text("Something went wrong") }, text = { Text(ui.error ?: "") })
    }
    if (ui.message != null) {
        LaunchedEffect(ui.message) {
            kotlinx.coroutines.delay(1200)
            vm.clearMessage()
        }
    }
    if (showDelete != null) {
        AlertDialog(
            onDismissRequest = { showDelete = null },
            title = { Text("Delete this transaction?") },
            text = { Text("The affected balances and reports will be recalculated automatically.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteTransaction(showDelete!!.id); showDelete = null }) { Text("DELETE") }
            },
            dismissButton = { TextButton(onClick = { showDelete = null }) { Text("CANCEL") } }
        )
    }

    Scaffold(
        containerColor = Bg,
        topBar = {
            if (screen != Screen.DASHBOARD) {
                TopAppBar(
                    title = { Text(screen.title()) },
                    navigationIcon = { IconButton(onClick = { screen = Screen.DASHBOARD }) { Icon(Icons.Default.ArrowBack, null) } }
                )
            }
        },
        bottomBar = {
            if (screen in setOf(Screen.DASHBOARD, Screen.HISTORY, Screen.UTANG, Screen.REPORTS, Screen.SETTINGS)) {
                NavigationBar {
                    NavItem("Home", Icons.Default.Home, screen == Screen.DASHBOARD) { screen = Screen.DASHBOARD }
                    NavItem("History", Icons.Default.History, screen == Screen.HISTORY) { screen = Screen.HISTORY }
                    NavItem("Utang", Icons.Default.People, screen == Screen.UTANG) { screen = Screen.UTANG }
                    NavItem("Reports", Icons.Default.Assessment, screen == Screen.REPORTS) { screen = Screen.REPORTS }
                    NavItem("Settings", Icons.Default.Settings, screen == Screen.SETTINGS) { screen = Screen.SETTINGS }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (screen) {
                Screen.DASHBOARD -> DashboardScreen(ui, onAction = { action ->
                    when (action) {
                        "UTANG" -> screen = Screen.UTANG
                        "TRANSFER" -> screen = Screen.TRANSFER
                        "AUDIT" -> screen = Screen.AUDIT
                        "LOAD" -> screen = Screen.LOAD
                        else -> { presetService = action; screen = Screen.FORM }
                    }
                })
                Screen.HISTORY -> HistoryScreen(ui, onEdit = { selectedTransaction = it; screen = Screen.EDIT }, onDelete = { showDelete = it })
                Screen.UTANG -> UtangScreen(ui, vm, onBorrow = { selectedCustomerId = it; debtMode = DebtType.BORROW.name; screen = Screen.DEBT }, onPay = { selectedCustomerId = it; debtMode = DebtType.PAYMENT.name; screen = Screen.DEBT })
                Screen.REPORTS -> ReportsScreen(ui)
                Screen.SETTINGS -> SettingsScreen(ui, vm, onBackup = { createBackup.launch("TARAKAN-DIGITAL-backup.json") }, onRestore = { restoreLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) })
                Screen.FORM -> ServiceFormScreen(ui, presetService, vm, onDone = { screen = Screen.DASHBOARD })
                Screen.LOAD -> LoadFormScreen(ui, vm, onDone = { screen = Screen.DASHBOARD })
                Screen.TRANSFER -> TransferScreen(vm, onDone = { screen = Screen.DASHBOARD })
                Screen.AUDIT -> AuditScreen(ui, vm)
                Screen.DEBT -> DebtFormScreen(ui, vm, debtMode, selectedCustomerId ?: 0L, onDone = { screen = Screen.UTANG })
                Screen.EDIT -> selectedTransaction?.let { EditTransactionScreen(it, ui, vm, onDone = { screen = Screen.HISTORY }) }
            }
        }
    }
}

private fun Screen.title(): String = when (this) {
    Screen.DASHBOARD -> "TARAKAN DIGITAL"
    Screen.HISTORY -> "Transaction History"
    Screen.UTANG -> "Customer Utang"
    Screen.REPORTS -> "Reports"
    Screen.SETTINGS -> "Service & App Settings"
    Screen.FORM -> "Service Transaction"
    Screen.LOAD -> "Load / eLoad"
    Screen.TRANSFER -> "Transfer"
    Screen.AUDIT -> "Cash Audit"
    Screen.DEBT -> "Utang Transaction"
    Screen.EDIT -> "Edit Transaction"
}

@Composable
private fun RowScope.NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(selected = selected, onClick = onClick, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 11.sp) })
}

@Composable
private fun FirstSetupScreen(onSave: (Long, Long, Long) -> Unit) {
    var cash by remember { mutableStateOf("") }
    var gcash by remember { mutableStateOf("") }
    var palawan by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp), verticalArrangement = Arrangement.Center) {
        Text("TARAKAN DIGITAL", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Green)
        Text("Business Cash & Transaction Tracker", color = Color.Gray)
        Spacer(Modifier.height(28.dp))
        Card(shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Initial setup", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Starting balances are not income.", color = Color.Gray)
                Spacer(Modifier.height(14.dp))
                MoneyInput("Physical Cash", cash) { cash = it }
                MoneyInput("GCash", gcash) { gcash = it }
                MoneyInput("PalawanPay", palawan) { palawan = it }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { onSave(Money.parse(cash) ?: 0L, Money.parse(gcash) ?: 0L, Money.parse(palawan) ?: 0L) },
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) { Text("START USING THE APP", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun DashboardScreen(ui: UiState, onAction: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("TARAKAN DIGITAL", fontSize = 29.sp, fontWeight = FontWeight.Black, color = Green)
            Text("Business Cash & Transaction Tracker", color = Color.Gray)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                BalanceCard("💵 Physical Cash", ui.cash, Modifier.weight(1f))
                BalanceCard("📱 GCash", ui.gcash, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                BalanceCard("💳 PalawanPay", ui.palawan, Modifier.weight(1f))
                BalanceCard("🧾 Customer Utang", ui.utang, Modifier.weight(1f))
            }
        }
        item { MetricCard("Today's Service Income", ui.incomeToday) }
        item { MetricCard("Total Business Money", ui.totalBusinessMoney, prominent = true) }
        item { Text("Quick Actions", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Green) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                ActionRow("+ CASH IN", ServiceType.CASH_IN.name, "- CASH OUT", ServiceType.CASH_OUT.name, onAction)
                ActionRow("📱 GCASH", ServiceType.GCASH.name, "💳 PALAWANPAY", ServiceType.PALAWANPAY.name, onAction)
                ActionRow("📲 LOAD", "LOAD", "🔳 QR CASH-IN", ServiceType.QR_CASH_IN.name, onAction)
                ActionRow("🧾 UTANG", "UTANG", "🔄 TRANSFER", "TRANSFER", onAction)
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { onAction("AUDIT") }, modifier = Modifier.weight(1f).height(54.dp)) { Text("📊 AUDIT") }
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun BalanceCard(title: String, amount: Long, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontSize = 13.sp, color = Color.Gray)
            Spacer(Modifier.height(3.dp))
            Text(Money.format(amount), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Green)
        }
    }
}

@Composable
private fun MetricCard(title: String, amount: Long, prominent: Boolean = false) {
    Card(
        colors = CardDefaults.cardColors(containerColor = if (prominent) Green else Color.White),
        shape = RoundedCornerShape(17.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text(title, color = if (prominent) Color.White.copy(alpha = .85f) else Color.Gray)
            Text(Money.format(amount), fontSize = if (prominent) 31.sp else 25.sp, fontWeight = FontWeight.Black, color = if (prominent) Color.White else Green)
        }
    }
}

@Composable
private fun ActionRow(a: String, ak: String, b: String, bk: String, onAction: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
        Button(onClick = { onAction(ak) }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(14.dp)) { Text(a, fontWeight = FontWeight.Bold) }
        Button(onClick = { onAction(bk) }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Green2)) { Text(b, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun ServiceFormScreen(ui: UiState, preset: String, vm: BusinessViewModel, onDone: () -> Unit) {
    var service by remember { mutableStateOf(preset) }
    var amount by remember { mutableStateOf("") }
    var fee by remember { mutableStateOf("") }
    var feeAuto by remember { mutableStateOf(true) }
    var source by remember { mutableStateOf(AccountIds.GCASH) }
    var destination by remember { mutableStateOf(AccountIds.CASH) }
    var notes by remember { mutableStateOf("") }
    var customerId by remember { mutableStateOf<Long?>(null) }
    val amountCents = Money.parse(amount) ?: 0L
    val setting = ui.fees[service]
    val computedFee = when (setting?.feeMode) {
        FeeMode.PERCENT.name -> Money.percentageFee(amountCents, setting.feeValue)
        FeeMode.FIXED.name -> Money.parse(setting.feeValue.toString()) ?: 0L
        else -> 0L
    }
    LaunchedEffect(service, amount, setting?.feeMode, setting?.feeValue) {
        if (feeAuto) fee = if (computedFee == 0L) "" else "%.2f".format(Locale.US, computedFee / 100.0)
    }
    LaunchedEffect(Unit) {
        when (service) {
            ServiceType.CASH_IN.name, ServiceType.QR_CASH_IN.name -> { source = AccountIds.CASH; destination = AccountIds.GCASH }
            ServiceType.CASH_OUT.name -> { source = AccountIds.GCASH; destination = AccountIds.CASH }
            ServiceType.GCASH.name -> { source = AccountIds.CASH; destination = AccountIds.GCASH }
            ServiceType.PALAWANPAY.name -> { source = AccountIds.CASH; destination = AccountIds.PALAWANPAY }
            else -> { source = AccountIds.CASH; destination = AccountIds.GCASH }
        }
    }
    val total = amountCents + (Money.parse(fee) ?: 0L)
    FormScaffold("Service", onDone) {
        DropdownField("SERVICE", service, ui.services.map { it.code to it.name }) { service = it; feeAuto = true }
        MoneyInput("TRANSACTION AMOUNT", amount) { amount = it }
        MoneyInput("SERVICE CHARGE", fee, enabled = true) { fee = it; feeAuto = false }
        Text(if (feeAuto) "Using configured default fee" else "Manual fee override", color = Color.Gray, fontSize = 12.sp)
        Text("TOTAL CUSTOMER PAYS", fontWeight = FontWeight.Bold)
        Text(Money.format(total), fontSize = 26.sp, fontWeight = FontWeight.Black, color = Green)
        Spacer(Modifier.height(8.dp))
        if (service == ServiceType.CASH_IN.name) {
            StaticAccount("SOURCE ACCOUNT", "Physical Cash")
            DropdownField("DESTINATION ACCOUNT", destination, listOf(AccountIds.GCASH to "GCash", AccountIds.PALAWANPAY to "PalawanPay")) { destination = it }
        } else if (service == ServiceType.CASH_OUT.name) {
            DropdownField("SOURCE ACCOUNT", source, listOf(AccountIds.GCASH to "GCash", AccountIds.PALAWANPAY to "PalawanPay")) { source = it }
            StaticAccount("DESTINATION ACCOUNT", "Physical Cash")
        } else {
            DropdownField("SOURCE ACCOUNT", source, listOf(AccountIds.CASH to "Physical Cash", AccountIds.GCASH to "GCash", AccountIds.PALAWANPAY to "PalawanPay")) { source = it }
            DropdownField("DESTINATION ACCOUNT", destination, listOf(AccountIds.CASH to "Physical Cash", AccountIds.GCASH to "GCash", AccountIds.PALAWANPAY to "PalawanPay")) { destination = it }
        }
        CustomerDropdown(ui.customers, customerId) { customerId = it }
        NotesInput(notes) { notes = it }
        Button(
            onClick = {
                val a = Money.parse(amount) ?: 0L
                val f = Money.parse(fee) ?: 0L
                vm.addService(service, a, f, source, destination, customerId, notes)
                onDone()
            },
            modifier = Modifier.fillMaxWidth().height(55.dp)
        ) { Text("SAVE TRANSACTION", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun LoadFormScreen(ui: UiState, vm: BusinessViewModel, onDone: () -> Unit) {
    var cost by remember { mutableStateOf("") }
    var selling by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf(AccountIds.CASH) }
    var costAccount by remember { mutableStateOf(AccountIds.GCASH) }
    var customerId by remember { mutableStateOf<Long?>(null) }
    var notes by remember { mutableStateOf("") }
    var sellingAuto by remember { mutableStateOf(true) }
    val markup = ui.fees[ServiceType.LOAD.name]?.defaultMarkupCents ?: 0L
    LaunchedEffect(cost, markup) {
        if (sellingAuto) {
            val c = Money.parse(cost) ?: 0L
            selling = if (c > 0L) "%.2f".format(Locale.US, (c + markup) / 100.0) else ""
        }
    }
    val profit = (Money.parse(selling) ?: 0L) - (Money.parse(cost) ?: 0L)
    FormScaffold("Load / eLoad", onDone) {
        MoneyInput("LOAD COST", cost) { cost = it }
        MoneyInput("SELLING PRICE / CUSTOMER PAYS", selling) { selling = it; sellingAuto = false }
        Text("Markup / profit: ${Money.format(profit.coerceAtLeast(0L))}", fontWeight = FontWeight.Bold, color = Green)
        DropdownField("PAYMENT ACCOUNT", payment, accountOptions()) { payment = it }
        DropdownField("COST ACCOUNT", costAccount, accountOptions()) { costAccount = it }
        CustomerDropdown(ui.customers, customerId) { customerId = it }
        NotesInput(notes) { notes = it }
        Button(onClick = { vm.addLoad(Money.parse(cost) ?: 0L, Money.parse(selling) ?: 0L, payment, costAccount, customerId, notes); onDone() }, modifier = Modifier.fillMaxWidth().height(55.dp)) {
            Text("SAVE LOAD", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TransferScreen(vm: BusinessViewModel, onDone: () -> Unit) {
    var source by remember { mutableStateOf(AccountIds.GCASH) }
    var dest by remember { mutableStateOf(AccountIds.PALAWANPAY) }
    var amount by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    FormScaffold("Transfer", onDone) {
        DropdownField("SOURCE ACCOUNT", source, accountOptions()) { source = it }
        DropdownField("DESTINATION ACCOUNT", dest, accountOptions()) { dest = it }
        MoneyInput("TRANSFER AMOUNT", amount) { amount = it }
        Text("Internal transfer: no revenue and no expense.", color = Color.Gray)
        NotesInput(notes) { notes = it }
        Button(onClick = { vm.addTransfer(source, dest, Money.parse(amount) ?: 0L, notes); onDone() }, modifier = Modifier.fillMaxWidth().height(55.dp)) { Text("SAVE TRANSFER", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun DebtFormScreen(ui: UiState, vm: BusinessViewModel, mode: String, customerId: Long, onDone: () -> Unit) {
    val customer = ui.customers.firstOrNull { it.id == customerId }
    var amount by remember { mutableStateOf("") }
    var account by remember { mutableStateOf(AccountIds.CASH) }
    var notes by remember { mutableStateOf("") }
    val outstanding = ui.customerBalances[customerId] ?: 0L
    FormScaffold(if (mode == DebtType.BORROW.name) "New Utang" else "Utang Payment", onDone) {
        Text(customer?.name ?: "Customer", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Outstanding: ${Money.format(outstanding)}", color = Green, fontWeight = FontWeight.Bold)
        MoneyInput("AMOUNT", amount) { amount = it }
        DropdownField(if (mode == DebtType.BORROW.name) "FUNDING ACCOUNT" else "PAYMENT ACCOUNT", account, accountOptions()) { account = it }
        NotesInput(notes) { notes = it }
        Button(
            onClick = {
                val a = Money.parse(amount) ?: 0L
                if (mode == DebtType.BORROW.name) vm.addBorrow(customerId, account, a, notes) else vm.addPayment(customerId, account, a, notes)
                onDone()
            },
            modifier = Modifier.fillMaxWidth().height(55.dp)
        ) { Text("SAVE", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun AuditScreen(ui: UiState, vm: BusinessViewModel) {
    var actual by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    val expected = ui.cash
    val actualCents = Money.parse(actual) ?: 0L
    val diff = actualCents - expected
    val status = when { actual.isBlank() -> ""; diff == 0L -> "MATCH"; diff < 0L -> "SHORT ${Money.format(-diff)}"; else -> "OVER ${Money.format(diff)}" }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { MetricCard("EXPECTED CASH", expected, prominent = true) }
        item { MoneyInput("ACTUAL CASH COUNTED", actual) { actual = it } }
        item {
            Card(shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("RESULT", color = Color.Gray)
                Text(status.ifBlank { "—" }, fontSize = 28.sp, fontWeight = FontWeight.Black, color = Green)
                if (actual.isNotBlank()) Text("Difference: ${Money.format(diff)}", color = Color.Gray)
            } }
        }
        item { NotesInput(notes) { notes = it } }
        item { Button(onClick = { vm.addAudit(actualCents, notes); actual = "" }, modifier = Modifier.fillMaxWidth().height(55.dp)) { Text("SAVE AUDIT", fontWeight = FontWeight.Bold) } }
        item { Text("Past Audits", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Green) }
        items(ui.audits.take(20)) { a ->
            Card { Column(Modifier.padding(14.dp)) {
                Text(a.timestamp.formatDate(), fontWeight = FontWeight.Bold)
                Text("Expected ${Money.format(a.expectedCashCents)} • Actual ${Money.format(a.actualCashCents)}")
                Text(when { a.differenceCents == 0L -> "MATCH"; a.differenceCents < 0L -> "SHORT ${Money.format(-a.differenceCents)}"; else -> "OVER ${Money.format(a.differenceCents)}" }, color = Green, fontWeight = FontWeight.Bold)
            } }
        }
    }
}

@Composable
private fun HistoryScreen(ui: UiState, onEdit: (TransactionEntity) -> Unit, onDelete: (TransactionEntity) -> Unit) {
    var query by remember { mutableStateOf("") }
    var period by remember { mutableStateOf("Today") }
    var typeFilter by remember { mutableStateOf("All") }
    var startDateText by remember { mutableStateOf(LocalDate.now().toString()) }
    var endDateText by remember { mutableStateOf(LocalDate.now().toString()) }
    val customRange = if (period == "Custom") {
        runCatching {
            val a = LocalDate.parse(startDateText)
            val b = LocalDate.parse(endDateText)
            DateUtils.startOf(a) to DateUtils.endOf(b)
        }.getOrNull()
    } else null
    val list = remember(ui.transactions, ui.customers, query, period, typeFilter, startDateText, endDateText) {
        val now = LocalDate.now()
        val range = customRange ?: when (period) {
            "Today" -> DateUtils.todayStart() to DateUtils.todayEnd()
            "Yesterday" -> DateUtils.startOf(now.minusDays(1)) to DateUtils.endOf(now.minusDays(1))
            "Week" -> DateUtils.thisWeekStart() to DateUtils.todayEnd()
            "Month" -> DateUtils.thisMonthStart() to DateUtils.todayEnd()
            else -> Long.MIN_VALUE to Long.MAX_VALUE
        }
        ui.transactions.filter { tx ->
            val customerName = ui.customers.firstOrNull { it.id == tx.customerId }?.name.orEmpty()
            tx.timestamp in range.first..range.second &&
                (typeFilter == "All" ||
                    (typeFilter == "Service Fees" && tx.incomeDeltaCents > 0L) ||
                    (typeFilter == "Cash In" && tx.serviceCode == ServiceType.CASH_IN.name) ||
                    (typeFilter == "Cash Out" && tx.serviceCode == ServiceType.CASH_OUT.name) ||
                    (typeFilter == "Load" && tx.type == TxType.LOAD.name) ||
                    (typeFilter == "Utang" && tx.type.startsWith("UTANG")) ||
                    (typeFilter == "Transfer" && tx.type == TxType.TRANSFER.name)) &&
                (query.isBlank() || tx.notes.contains(query, true) || customerName.contains(query, true) ||
                    (tx.serviceCode ?: tx.type).contains(query, true))
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search history") })
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Today", "Yesterday", "Week", "Month", "Custom", "All").forEach { p -> FilterChip(selected = period == p, onClick = { period = p }, label = { Text(p, fontSize = 12.sp) }) } }
        Spacer(Modifier.height(5.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("All", "Cash In", "Cash Out", "Load", "Utang", "Transfer", "Service Fees").forEach { t -> FilterChip(selected = typeFilter == t, onClick = { typeFilter = t }, label = { Text(t, fontSize = 11.sp) }) } }
        if (period == "Custom") {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(startDateText, { startDateText = it }, label = { Text("Start YYYY-MM-DD") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(endDateText, { endDateText = it }, label = { Text("End YYYY-MM-DD") }, modifier = Modifier.weight(1f), singleLine = true)
            }
        }
        Spacer(Modifier.height(10.dp))
        if (period == "Custom" && customRange == null) Text("Use dates like 2026-09-20.", color = Color(0xFFB3261E))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(list) { tx -> TransactionCard(tx, ui.customers, onEdit, onDelete) }
        }
    }
}

@Composable
private fun TransactionCard(tx: TransactionEntity, customers: List<CustomerEntity>, onEdit: (TransactionEntity) -> Unit, onDelete: (TransactionEntity) -> Unit) {
    Card(shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text((tx.serviceCode?.let { ServiceType.entries.firstOrNull { s -> s.name == it }?.label } ?: TxType.entries.firstOrNull { t -> t.name == tx.type }?.label) ?: tx.type, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(tx.timestamp.formatDate(), color = Color.Gray, fontSize = 12.sp)
                }
                Text(Money.format(tx.amountCents), fontWeight = FontWeight.Black, color = Green)
            }
            if (tx.feeCents > 0L) Text("Fee: ${Money.format(tx.feeCents)} • Total paid: ${Money.format(tx.totalCustomerPaymentCents)}", color = Color.Gray)
            if (tx.type == TxType.LOAD.name) Text("Cost ${Money.format(tx.loadCostCents)} → Profit ${Money.format(tx.incomeDeltaCents)}", color = Green)
            if (tx.sourceAccountId != null || tx.destinationAccountId != null) Text("${accountLabel(tx.sourceAccountId)} → ${accountLabel(tx.destinationAccountId)}", color = Color.Gray)
            tx.customerId?.let { id -> customers.firstOrNull { it.id == id }?.let { Text("Customer: ${it.name}", color = Color.Gray) } }
            if (tx.type.startsWith("UTANG")) Text(if (tx.type == TxType.UTANG_BORROW.name) "Customer borrowed" else "Customer paid", color = Color.Gray)
            if (tx.notes.isNotBlank()) Text(tx.notes, color = Color.Gray)
            Spacer(Modifier.height(5.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onEdit(tx) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(5.dp)); Text("EDIT") }
                OutlinedButton(onClick = { onDelete(tx) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(5.dp)); Text("DELETE") }
            }
        }
    }
}

@Composable
private fun UtangScreen(ui: UiState, vm: BusinessViewModel, onBorrow: (Long) -> Unit, onPay: (Long) -> Unit) {
    var showAdd by remember { mutableStateOf(false) }
    if (showAdd) AddCustomerDialog(onDismiss = { showAdd = false }, onSave = { n, p, no -> vm.addCustomer(n, p, no); showAdd = false })
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("CUSTOMER UTANG", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Green); Text("Outstanding is principal, not income.", color = Color.Gray) }
            FilledTonalIconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null) }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(ui.customers) { c ->
                val bal = ui.customerBalances[c.id] ?: 0L
                Card {
                    Column(Modifier.padding(15.dp)) {
                        Text(c.name, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Text(Money.format(bal), fontSize = 24.sp, fontWeight = FontWeight.Black, color = if (bal > 0) Green2 else Color.Gray)
                        if (c.phone.isNotBlank()) Text(c.phone, color = Color.Gray)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onBorrow(c.id) }, modifier = Modifier.weight(1f)) { Text("NEW UTANG") }
                            OutlinedButton(onClick = { onPay(c.id) }, modifier = Modifier.weight(1f), enabled = bal > 0) { Text("PAYMENT") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddCustomerDialog(onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add Customer") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
        OutlinedTextField(phone, { phone = it }, label = { Text("Phone (optional)") }, singleLine = true)
        OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
    } }, confirmButton = { TextButton(onClick = { onSave(name, phone, notes) }) { Text("SAVE") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL") } })
}

@Composable
private fun ReportsScreen(ui: UiState) {
    var period by remember { mutableStateOf("Today") }
    var startDateText by remember { mutableStateOf(LocalDate.now().toString()) }
    var endDateText by remember { mutableStateOf(LocalDate.now().toString()) }
    val customRange = if (period == "Custom") runCatching {
        val a = LocalDate.parse(startDateText)
        val b = LocalDate.parse(endDateText)
        DateUtils.startOf(a) to DateUtils.endOf(b)
    }.getOrNull() else null
    val range = customRange ?: when (period) {
        "Today" -> DateUtils.todayStart() to DateUtils.todayEnd()
        "Week" -> DateUtils.thisWeekStart() to DateUtils.todayEnd()
        "Month" -> DateUtils.thisMonthStart() to DateUtils.todayEnd()
        else -> Long.MIN_VALUE to Long.MAX_VALUE
    }
    val tx = ui.transactions.filter { it.timestamp in range.first..range.second }
    val income = tx.sumOf { it.incomeDeltaCents }
    val loadProfit = tx.filter { it.type == TxType.LOAD.name }.sumOf { it.incomeDeltaCents }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Today", "Week", "Month", "Custom", "All").forEach { p -> FilterChip(selected = period == p, onClick = { period = p }, label = { Text(p, fontSize = 12.sp) }) } } }
        if (period == "Custom") item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(startDateText, { startDateText = it }, label = { Text("Start YYYY-MM-DD") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(endDateText, { endDateText = it }, label = { Text("End YYYY-MM-DD") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            if (customRange == null) Text("Use dates like 2026-09-20.", color = Color(0xFFB3261E))
        }
        item { MetricCard("Service Income", income, prominent = true) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) { BalanceCard("Cash", ui.cash, Modifier.weight(1f)); BalanceCard("GCash", ui.gcash, Modifier.weight(1f)) } }
        item { BalanceCard("PalawanPay", ui.palawan, Modifier.fillMaxWidth()) }
        item {
            Card { Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Income breakdown", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                ServiceType.entries.forEach { s ->
                    val v = tx.filter { it.serviceCode == s.name }.sumOf { it.incomeDeltaCents }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(s.label); Text(Money.format(v), fontWeight = FontWeight.Bold) }
                }
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Load profit"); Text(Money.format(loadProfit), fontWeight = FontWeight.Bold, color = Green) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Outstanding Customer Utang"); Text(Money.format(ui.utang), fontWeight = FontWeight.Bold) }
            } }
        }
    }
}

@Composable
private fun SettingsScreen(ui: UiState, vm: BusinessViewModel, onBackup: () -> Unit, onRestore: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Service Settings", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Green)
            Text("Default fees can be fixed, percentage, or manual. Transaction fees can always be overridden.", color = Color.Gray)
        }
        items(ui.services) { s -> FeeSettingCard(s, ui.fees[s.code], onSave = vm::saveFeeSetting) }
        item {
            Spacer(Modifier.height(8.dp))
            Text("Data", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Green)
            Button(onClick = onBackup, modifier = Modifier.fillMaxWidth().height(54.dp)) { Icon(Icons.Default.Backup, null); Spacer(Modifier.width(8.dp)); Text("BACKUP DATA") }
            OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth().height(54.dp)) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(8.dp)); Text("RESTORE DATA") }
            Text("Offline local backup only. No cloud account is required.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun FeeSettingCard(service: ServiceTypeEntity, setting: ServiceFeeSettingEntity?, onSave: (ServiceFeeSettingEntity) -> Unit) {
    var mode by remember(setting?.feeMode) { mutableStateOf(setting?.feeMode ?: FeeMode.MANUAL.name) }
    var value by remember(setting?.feeValue) { mutableStateOf(setting?.feeValue?.toString() ?: "0") }
    var markup by remember(setting?.defaultMarkupCents) { mutableStateOf("%.2f".format(Locale.US, (setting?.defaultMarkupCents ?: 0L) / 100.0)) }
    Card {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(service.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            DropdownField("FEE MODE", mode, FeeMode.entries.map { it.name to it.label }) { mode = it }
            OutlinedTextField(value, { value = it }, label = { Text(if (mode == FeeMode.PERCENT.name) "Percent (%)" else "Fee (₱)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            MoneyInput("DEFAULT LOAD MARKUP (₱)", markup) { markup = it }
            OutlinedButton(onClick = { onSave(ServiceFeeSettingEntity(service.code, mode, value.toDoubleOrNull() ?: 0.0, Money.parse(markup) ?: 0L)) }, modifier = Modifier.fillMaxWidth()) { Text("SAVE SETTING") }
        }
    }
}

@Composable
private fun EditTransactionScreen(tx: TransactionEntity, ui: UiState, vm: BusinessViewModel, onDone: () -> Unit) {
    var amount by remember(tx.id) { mutableStateOf((tx.amountCents / 100.0).toString()) }
    var fee by remember(tx.id) { mutableStateOf((tx.feeCents / 100.0).toString()) }
    var cost by remember(tx.id) { mutableStateOf((tx.loadCostCents / 100.0).toString()) }
    var selling by remember(tx.id) { mutableStateOf((tx.sellingPriceCents / 100.0).toString()) }
    var notes by remember(tx.id) { mutableStateOf(tx.notes) }
    FormScaffold("Edit Transaction", onDone) {
        Text(tx.serviceCode?.let { ServiceType.entries.firstOrNull { s -> s.name == it }?.label } ?: tx.type, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        MoneyInput("AMOUNT", amount) { amount = it }
        if (tx.type == TxType.SERVICE.name) MoneyInput("SERVICE CHARGE", fee) { fee = it }
        if (tx.type == TxType.LOAD.name) { MoneyInput("LOAD COST", cost) { cost = it }; MoneyInput("SELLING PRICE", selling) { selling = it } }
        if (tx.type == TxType.TRANSFER.name || tx.type.startsWith("UTANG")) Text("Accounts/customer are kept with this transaction.", color = Color.Gray)
        NotesInput(notes) { notes = it }
        Button(onClick = { vm.editTransaction(tx, Money.parse(amount) ?: 0L, Money.parse(fee) ?: 0L, Money.parse(cost) ?: 0L, Money.parse(selling) ?: 0L, notes); onDone() }, modifier = Modifier.fillMaxWidth().height(55.dp)) { Text("SAVE CHANGES", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun FormScaffold(title: String, onDone: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item { Text(title, fontSize = 27.sp, fontWeight = FontWeight.Black, color = Green) }
        item { Column(verticalArrangement = Arrangement.spacedBy(11.dp), content = content) }
    }
}

private fun accountOptions() = listOf(AccountIds.CASH to "Physical Cash", AccountIds.GCASH to "GCash", AccountIds.PALAWANPAY to "PalawanPay")
private fun accountLabel(id: String?): String = when (id) { AccountIds.CASH -> "Physical Cash"; AccountIds.GCASH -> "GCash"; AccountIds.PALAWANPAY -> "PalawanPay"; else -> "—" }

@Composable
private fun StaticAccount(label: String, value: String) { Column { Text(label, color = Color.Gray, fontSize = 12.sp); Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp) } }

@Composable
private fun MoneyInput(label: String, value: String, enabled: Boolean = true, onValueChange: (String) -> Unit) {
    OutlinedTextField(value, { input -> onValueChange(input.filter { it.isDigit() || it == '.' }) }, label = { Text(label) }, prefix = { Text("₱") }, singleLine = true, enabled = enabled, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
}

@Composable
private fun NotesInput(value: String, onValueChange: (String) -> Unit) { OutlinedTextField(value, onValueChange, label = { Text("Notes (optional)") }, minLines = 2, modifier = Modifier.fillMaxWidth()) }

@Composable
private fun DropdownField(label: String, value: String, options: List<Pair<String, String>>, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text(options.firstOrNull { it.first == value }?.second ?: value, fontWeight = FontWeight.Bold) }
        }
        DropdownMenu(expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (key, display) -> DropdownMenuItem(text = { Text(display) }, onClick = { onSelected(key); expanded = false }) }
        }
    }
}

@Composable
private fun CustomerDropdown(customers: List<CustomerEntity>, selectedId: Long?, onSelected: (Long?) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("CUSTOMER (OPTIONAL)"); Text(customers.firstOrNull { it.id == selectedId }?.name ?: "None", fontWeight = FontWeight.Bold) }
        }
        DropdownMenu(expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("None") }, onClick = { onSelected(null); expanded = false })
            customers.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { onSelected(c.id); expanded = false }) }
        }
    }
}

private fun Long.formatDate(): String = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()).format(Date(this))
